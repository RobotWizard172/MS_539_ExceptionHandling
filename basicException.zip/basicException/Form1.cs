﻿/* Jeff Koss
 * Date: 03/26/23
 * Class: MS - 539 Programming Concepts
 * Professor: Jill Coddington
 * Assignment: Exception Handeling
 */

// This assignment should only take me an hour.

/*This assignment took me longer than expected.
 * I wanted to make a program that would
 * be able to ask a user to input
 * a band from my record label.
 * However, when I tried to implement the Try -
 * Catch statement, it did not work as expected.
 * So I had to revert to something else and used
 * the assignment video to make things happen.
 * Even though it did not turn out as expected, I did get the program working,
 * It took me 2 hours.
 */

// Imports
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Namespace
namespace basicException
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int result; // an interger used to get input from the user
            string str = textBox1.Text; //a string used to output to the user

            if (int.TryParse(str, out result))
            {
                MessageBox.Show("This is a valid interger!"); // Is valid
            }
            else
            {
                MessageBox.Show("This is not a valid interger!"); // is not valid
            }

            try
            {
                int.Parse(str); // try to parse 
            }
            catch
            {
                MessageBox.Show("CATCH - not a valid interger"); // did not parse
                MessageBox.Show("Please try again!");
            }

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
